ZTF J1901+1458.exe
                                                                                                                                                         
Malware Name: ZTF J1901+1458
Malware Type: Trojan
Damage Rate: Destructive
Works best on: Windows XP
made in: c++, asm
Creator: Hugopako
Creation date: 7 May 2024
This malware is not a joke, run it only on vm, i'm not responsible for any damages